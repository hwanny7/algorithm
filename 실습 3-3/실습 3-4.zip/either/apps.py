from django.apps import AppConfig


class EitherConfig(AppConfig):
    name = 'either'
